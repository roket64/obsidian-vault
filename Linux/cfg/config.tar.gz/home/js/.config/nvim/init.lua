require("config.lazy")

-- disable backups
vim.o.backup=false      -- disable backup files
vim.o.writebackup=false -- disable backup before overwriting
vim.o.swapfile=false    -- disable swap files

-- indentation options
vim.o.autoindent=true   -- automatically indent 
vim.o.smarttab=true     -- use smart indent
vim.o.smartindent=true  -- use smart indent
vim.o.expandtab=true    -- convert tabs to spaces
vim.o.tabstop=2
vim.o.softtabstop=2
vim.o.shiftwidth=2

-- interface options
vim.o.rnu=true    -- enable relative line number
vim.o.ruler=true  -- show cursor position in the bar

-- search options
vim.o.hlsearch=true   -- hightlight all matched results
vim.o.incsearch=true  -- 
vim.o.ignorecase=true -- enable case-insensitive search
vim.o.smartcase=true  -- disable ignorecase when search pattern has uppercase letters
vim.o.showmatch=true  -- enable live match highlighting
